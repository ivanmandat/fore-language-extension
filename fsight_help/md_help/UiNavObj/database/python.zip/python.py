import jaydebeapi as jdbc

class jdbc_prm:
	def __init__(self, jdbc_class, jar_path, jdbc_url, db_user, db_pswd):
		self.j_class = jdbc_class
		self.j_path = jar_path
		self.j_url = jdbc_url
		self.db_user = db_user
		self.db_pswd = db_pswd

def load_data_jdbc(jdbc_prm, sqltext):
	rows = []
	try:
		conn = jdbc.connect(jdbc_prm.j_class, jdbc_prm.j_url, [jdbc_prm.db_user, jdbc_prm.db_pswd], jdbc_prm.j_path)
		curs = conn.cursor()
		curs.execute(sqltext)
		rows = curs.fetchall()
		curs.close()
		conn.close()
	except Exception as e:
		print(str(e))
	finally:
		return rows